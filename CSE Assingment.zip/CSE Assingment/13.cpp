#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    int x;
    cin>>x;
    cout<<"log(x) = "<<log(x);
    return 0;
}