#include<iostream>
using namespace std;
int sum(int a,int b)
{
    return (a+b);
}
int main()
{
    int x = 9; 
    int y = 10;
    cout<<"sum = "<<sum(x,y)<<endl;
}