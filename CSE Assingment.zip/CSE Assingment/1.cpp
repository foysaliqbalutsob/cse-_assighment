#include<iostream>
using namespace std;
int main()
{
    cout<<"My name is DEB POSAD SEN";
    return 0;
}